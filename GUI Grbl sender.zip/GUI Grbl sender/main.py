"""
Jednoduché GUI (tkinter) s dvoma tlačidlami.
Každé tlačidlo odošle svoj G-code súbor do dosky s GRBL cez sériový port.

Závislosti:  pip install pyserial
"""

import queue
import re
import threading
import time
import tkinter as tk
from tkinter import messagebox, scrolledtext

import serial

# ----------------------------- NASTAVENIA -----------------------------
PORT = "COM3"          # Linux: "/dev/ttyUSB0" alebo "/dev/ttyACM0"
BAUD = 115200          # štandard pre GRBL 1.1

# (text tlačidla, cesta k G-code súboru)
PROGRAMY = [
    ("Spustiť program 1", "program1.gcode"),
    ("Spustiť program 2", "program2.gcode"),
]
# ----------------------------------------------------------------------


def vycisti_riadok(riadok: str) -> str:
    """Odstráni komentáre a biele znaky z riadku G-code."""
    riadok = re.sub(r"\(.*?\)", "", riadok)  # komentáre v zátvorkách
    riadok = riadok.split(";")[0]            # komentáre za bodkočiarkou
    return riadok.strip()


def odosli_gcode(cesta: str, log):
    """Odošle súbor riadok po riadku a čaká na 'ok' od GRBL."""
    with open(cesta, "r", encoding="utf-8") as f:
        riadky = [vycisti_riadok(r) for r in f]
    riadky = [r for r in riadky if r]

    log(f"Pripájam sa na {PORT} @ {BAUD}...")
    with serial.Serial(PORT, BAUD, timeout=1) as s:
        # Prebudenie GRBL
        s.write(b"\r\n\r\n")
        time.sleep(2)
        s.reset_input_buffer()

        celkom = len(riadky)
        for i, riadok in enumerate(riadky, start=1):
            s.write((riadok + "\n").encode("ascii"))

            # Čakanie na odpoveď
            while True:
                odpoved = s.readline().decode("ascii", errors="ignore").strip()
                if not odpoved:
                    continue
                if odpoved == "ok":
                    break
                if odpoved.startswith("error"):
                    raise RuntimeError(
                        f"Riadok {i}: '{riadok}' -> {odpoved}"
                    )
                log(f"GRBL: {odpoved}")

            log(f"[{i}/{celkom}] {riadok}")

    log("Hotovo.")


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("GRBL odosielač G-code")
        self.geometry("480x340")

        self.fronta = queue.Queue()
        self.tlacidla = []

        rám = tk.Frame(self)
        rám.pack(pady=10)

        for text, cesta in PROGRAMY:
            b = tk.Button(
                rám, text=text, width=20, height=2,
                command=lambda c=cesta: self.spusti(c),
            )
            b.pack(side=tk.LEFT, padx=10)
            self.tlacidla.append(b)

        self.vystup = scrolledtext.ScrolledText(self, state="disabled", height=12)
        self.vystup.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))

        self.after(100, self.spracuj_frontu)

    # ---- logovanie (bezpečné pre vlákna cez frontu) ----
    def log(self, text: str):
        self.fronta.put(("log", text))

    def spracuj_frontu(self):
        try:
            while True:
                typ, data = self.fronta.get_nowait()
                if typ == "log":
                    self.vystup.config(state="normal")
                    self.vystup.insert(tk.END, data + "\n")
                    self.vystup.see(tk.END)
                    self.vystup.config(state="disabled")
                elif typ == "koniec":
                    self.nastav_tlacidla(tk.NORMAL)
                elif typ == "chyba":
                    self.nastav_tlacidla(tk.NORMAL)
                    messagebox.showerror("Chyba", data)
        except queue.Empty:
            pass
        self.after(100, self.spracuj_frontu)

    def nastav_tlacidla(self, stav):
        for b in self.tlacidla:
            b.config(state=stav)

    # ---- spustenie odosielania v samostatnom vlákne ----
    def spusti(self, cesta: str):
        self.nastav_tlacidla(tk.DISABLED)
        self.log(f"--- Spúšťam súbor: {cesta} ---")
        threading.Thread(target=self.pracovne_vlakno, args=(cesta,), daemon=True).start()

    def pracovne_vlakno(self, cesta: str):
        try:
            odosli_gcode(cesta, self.log)
            self.fronta.put(("koniec", None))
        except FileNotFoundError:
            self.log(f"Súbor '{cesta}' sa nenašiel.")
            self.fronta.put(("chyba", f"Súbor '{cesta}' sa nenašiel."))
        except serial.SerialException as e:
            self.log(f"Chyba sériového portu: {e}")
            self.fronta.put(("chyba", f"Chyba sériového portu:\n{e}"))
        except Exception as e:
            self.log(f"Chyba: {e}")
            self.fronta.put(("chyba", str(e)))


if __name__ == "__main__":
    App().mainloop()